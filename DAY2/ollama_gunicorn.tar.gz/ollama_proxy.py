from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

OLLAMA_URL = "http://192.168.1.37:11434/api/generate"

@app.route("/")
def home():
    return "Proxy is running"

@app.route("/v1/chat/completions", methods=["POST"])
def chat():
    data = request.json

    messages = data.get("messages", [])
    prompt = messages[-1]["content"] if messages else ""

    r = requests.post(OLLAMA_URL, json={
        "model": "phi3-local",
        "prompt": prompt,
        "stream": False,
        "options": {
            "num_predict": 200,
            "temperature": 0.2
        }
    })

    result = r.json()

    return jsonify({
        "choices": [
            {
                "message": {
                    "content": result.get("response", "")
                }
            }
        ]
    })
